(function () {
    "use strict";
    setup.GeneratedModelList = {
    "schemaVersion": 1,
    "defaultModelId": "thedrummer/cydonia-24b-v4.1",
    "defaultNarratorModelId": "sao10k/l3.3-euryale-70b:nitro",
    "defaultUtilityModelId": "deepseek/deepseek-v4-flash",
    "models": [
        {
            "id": "thedrummer/cydonia-24b-v4.1",
            "name": "Cydonia 24B V4.1"
        },
        {
            "id": "sao10k/l3.3-euryale-70b",
            "name": "Llama 3.3 Euryale 70B"
        },
        {
            "id": "sao10k/l3.3-euryale-70b:nitro",
            "name": "Llama 3.3 Euryale 70B (Nitro)"
        },
        {
            "id": "sao10k/l3.1-euryale-70b:nitro",
            "name": "Llama 3.1 Euryale 70B (Nitro)"
        },
        {
            "id": "mistralai/mistral-small-3.2-24b-instruct",
            "name": "Mistral Small 3.2 24B"
        },
        {
            "id": "deepseek/deepseek-v4-pro",
            "name": "DeepSeek V4 Pro"
        },
        {
            "id": "deepseek/deepseek-v4-flash",
            "name": "DeepSeek V4 Flash"
        }
    ]
};
}());

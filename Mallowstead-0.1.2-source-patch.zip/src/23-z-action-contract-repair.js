(function () {
    "use strict";

    const stats = {
        characterDecisions: 0,
        detectorTriggered: 0,
        repairAttempted: 0,
        repairNoViolation: 0,
        repairSucceeded: 0,
        repairWholeResponseRejected: 0,
        triggerMechanics: {},
        repairedActions: {}
    };

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function incrementMap(map, key) {
        if (!key) return;
        map[key] = (map[key] || 0) + 1;
    }

    function registry() {
        return setup.Game && setup.Game.ActionRegistry || {};
    }

    function repairClassFor(type) {
        const definition = registry()[type];
        return definition && definition.repairClass || type || null;
    }

    function escapeRegex(value) {
        return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }

    function keywordMatches(text, keyword) {
        const source = String(text || "").toLowerCase();
        const needle = String(keyword || "").trim().toLowerCase();
        if (!source || !needle) return false;
        const first = needle.charAt(0);
        const last = needle.charAt(needle.length - 1);
        const prefix = /[a-z0-9_]/i.test(first) ? "\\b" : "";
        const suffix = /[a-z0-9_]/i.test(last) ? "\\b" : "";
        return new RegExp(prefix + escapeRegex(needle) + suffix, "i").test(source);
    }

    function keywordCatalog() {
        const catalog = [];
        Object.entries(registry()).forEach(function (entry) {
            const type = entry[0];
            const definition = entry[1] || {};
            (definition.repairKeywords || []).forEach(function (keyword) {
                catalog.push({ type: type, repairClass: definition.repairClass || type, keyword: String(keyword) });
            });
        });
        const world = setup.Game && setup.Game.getWorld ? setup.Game.getWorld() : null;
        Object.values(world && world.itemDefinitions || {}).forEach(function (definition) {
            [
                ["use_item", definition && definition.useAction],
                ["fill", definition && definition.fillAction],
                ["consume", definition && definition.consumeAction]
            ].forEach(function (pair) {
                const type = pair[0];
                const action = pair[1];
                if (!action || !Array.isArray(action.repairKeywords)) return;
                action.repairKeywords.forEach(function (keyword) {
                    catalog.push({ type: type, repairClass: repairClassFor(type), keyword: String(keyword) });
                });
            });
        });
        const seen = new Set();
        return catalog.filter(function (entry) {
            const key = `${entry.type}\u0000${entry.keyword.toLowerCase()}`;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    function detect(decision) {
        const selectedType = decision && decision.action && decision.action.type || null;
        const selectedClass = selectedType ? repairClassFor(selectedType) : null;
        const fields = [
            { field: "publicNarrative", text: decision && decision.publicNarrative || "" },
            { field: "spokenText", text: decision && decision.spokenText || "" }
        ];
        const signals = [];
        const seen = new Set();
        keywordCatalog().forEach(function (candidate) {
            if (selectedClass && candidate.repairClass === selectedClass) return;
            fields.forEach(function (record) {
                if (!keywordMatches(record.text, candidate.keyword)) return;
                const key = `${record.field}\u0000${candidate.type}\u0000${candidate.keyword.toLowerCase()}`;
                if (seen.has(key)) return;
                seen.add(key);
                signals.push({
                    field: record.field,
                    mechanicType: candidate.type,
                    repairClass: candidate.repairClass,
                    keyword: candidate.keyword
                });
            });
        });
        return {
            triggered: signals.length > 0,
            selectedActionType: selectedType,
            selectedRepairClass: selectedClass,
            signals: signals
        };
    }

    function repairSystemPrompt() {
        return "You are a narrow action-contract repair checker for Mallowstead. Do not roleplay or choose a new goal. Inspect the supplied Character decision only for claims that a tracked engine state change has already happened without being covered by its formal action. Keyword signals are suspicious hints, not proof: future intent, questions, requests, metaphors, and references to an object are not violations by themselves. If there is no actual violation, return violation=false and repairedDecision=null. If there is a violation, preserve the Character's existing intention and voice as much as possible. Choose at most one formal action from availableActions that is executable right now and legitimately advances the already-expressed intention; a prerequisite action is valid. Rewrite narrative/speech so they do not claim tracked effects beyond that one action. Never invent an action or option. If a real violation exists but no valid currently available action can repair it, return violation=true and repairedDecision=null. Return exactly one JSON object and no extra prose.";
    }

    function repairMessages(context, originalDecision, detection) {
        return [
            { role: "system", content: repairSystemPrompt() },
            { role: "user", content: JSON.stringify({
                stage: "action-contract-repair",
                detectorSignals: clone(detection.signals),
                originalDecision: clone(originalDecision),
                relevantMechanics: clone(context && context.relevantMechanics || {}),
                availableActions: clone(context && context.view && context.view.available_actions || {}),
                currentView: clone(context && context.view || {}),
                requiredResponseShape: {
                    violation: false,
                    repairedDecision: null
                },
                repairedDecisionContract: {
                    action: "null or one action from availableActions; when violation=true a usable repair requires a non-null action",
                    publicNarrative: "string|null",
                    spokenText: "string|null",
                    spokenTargetId: "string|null",
                    spokenLoudness: "noticeable|hidden|shout|null",
                    continuation: "string|null",
                    memoryUpdates: { relationshipsToUpsert: [], activatedBeliefIds: [] }
                }
            }) }
        ];
    }

    function validateDecisionAgainstContext(decision, context) {
        const validationMessages = setup.AIProtocol.decisionMessages(context || {});
        return setup.AIProtocol.validateDecision(
            decision,
            setup.AIProtocol.actionCatalogFromMessages(validationMessages),
            setup.AIProtocol.spokenTargetIdsFromMessages(validationMessages),
            setup.AIProtocol.existingBeliefIdsFromMessages(validationMessages),
            setup.AIProtocol.existingRelationshipsFromMessages(validationMessages)
        );
    }

    function validateEnvelope(value, context) {
        if (!value || typeof value !== "object" || Array.isArray(value)) return { ok: false, errors: ["Repair response must be an object."] };
        const keys = Object.keys(value).sort();
        if (keys.join(",") !== "repairedDecision,violation") return { ok: false, errors: ["Repair response must contain exactly violation and repairedDecision."] };
        if (typeof value.violation !== "boolean") return { ok: false, errors: ["violation must be boolean."] };
        if (value.violation === false) {
            if (value.repairedDecision !== null) return { ok: false, errors: ["repairedDecision must be null when violation is false."] };
            return { ok: true, value: { violation: false, repairedDecision: null } };
        }
        if (value.repairedDecision === null) return { ok: true, value: { violation: true, repairedDecision: null } };
        if (!value.repairedDecision || typeof value.repairedDecision !== "object" || Array.isArray(value.repairedDecision)) {
            return { ok: false, errors: ["repairedDecision must be an object or null."] };
        }
        const validation = validateDecisionAgainstContext(value.repairedDecision, context);
        if (!validation.ok) return validation;
        if (!validation.value || !validation.value.action) return { ok: false, errors: ["A confirmed violation requires one currently available formal action to repair it."] };
        return { ok: true, value: { violation: true, repairedDecision: validation.value } };
    }

    async function inspectAndRepair(actorId, context, originalDecision, client) {
        stats.characterDecisions += 1;
        const detection = detect(originalDecision);
        if (!detection.triggered) {
            return { ok: true, value: clone(originalDecision), triggered: false, repaired: false, noViolation: false, detection: detection };
        }

        stats.detectorTriggered += 1;
        const mechanicTypes = Array.from(new Set(detection.signals.map(function (signal) { return signal.mechanicType; })));
        mechanicTypes.forEach(function (type) { incrementMap(stats.triggerMechanics, type); });
        stats.repairAttempted += 1;

        const messages = repairMessages(context, originalDecision, detection);
        const result = await setup.AIRequestExecutor.executeCustom({
            actorId: actorId,
            purpose: "action-contract-repair",
            stage: "action-contract-repair",
            messages: messages,
            requestOptions: setup.AIRequestProfiles.resolve("action-contract-repair", { actorId: actorId }),
            client: client,
            run: function (policyClient) {
                return setup.StructuredAIRequest.run(policyClient, {
                    stage: "action-contract-repair",
                    messages: messages,
                    maxRepairAttempts: 0,
                    validate: function (value) { return validateEnvelope(value, context); },
                    validationErrorCode: "ACTION_CONTRACT_REPAIR_INVALID",
                    validationErrorMessage: "The Utility action-contract repair response was invalid.",
                    parseErrorCode: "ACTION_CONTRACT_REPAIR_INVALID",
                    parseErrorMessage: "The Utility action-contract repair response was malformed JSON.",
                    traceMessages: true
                });
            }
        });

        if (!result.ok) {
            stats.repairWholeResponseRejected += 1;
            return {
                ok: false,
                error: {
                    code: "ACTION_CONTRACT_REPAIR_FAILED",
                    message: "The Character response was rejected because action-contract repair failed.",
                    details: result.error ? [result.error.message || result.error.code || "Utility repair failed."] : []
                },
                detection: detection,
                repairResult: clone(result)
            };
        }

        if (result.value.violation === false) {
            stats.repairNoViolation += 1;
            return { ok: true, value: clone(originalDecision), triggered: true, repaired: false, noViolation: true, detection: detection, repairResult: clone(result) };
        }

        if (!result.value.repairedDecision || !result.value.repairedDecision.action) {
            stats.repairWholeResponseRejected += 1;
            return {
                ok: false,
                error: {
                    code: "ACTION_CONTRACT_REPAIR_NO_ACTION",
                    message: "The Character response was rejected because it claimed an ungrounded tracked effect and no valid current formal action could repair it."
                },
                detection: detection,
                repairResult: clone(result)
            };
        }

        const finalValidation = validateDecisionAgainstContext(result.value.repairedDecision, context);
        if (!finalValidation.ok || !finalValidation.value || !finalValidation.value.action) {
            stats.repairWholeResponseRejected += 1;
            return {
                ok: false,
                error: {
                    code: "ACTION_CONTRACT_REPAIR_REVALIDATION_FAILED",
                    message: "The Character response was rejected because the repaired decision failed deterministic validation.",
                    details: clone(finalValidation.errors || [])
                },
                detection: detection,
                repairResult: clone(result)
            };
        }

        stats.repairSucceeded += 1;
        incrementMap(stats.repairedActions, finalValidation.value.action.type);
        return {
            ok: true,
            value: clone(finalValidation.value),
            triggered: true,
            repaired: true,
            noViolation: false,
            detection: detection,
            repairResult: clone(result)
        };
    }

    function resetStats() {
        stats.characterDecisions = 0;
        stats.detectorTriggered = 0;
        stats.repairAttempted = 0;
        stats.repairNoViolation = 0;
        stats.repairSucceeded = 0;
        stats.repairWholeResponseRejected = 0;
        stats.triggerMechanics = {};
        stats.repairedActions = {};
        return { ok: true };
    }

    setup.AIActionContractRepair = {
        detect: detect,
        inspectAndRepair: inspectAndRepair,
        getStats: function () { return clone(stats); },
        resetStats: resetStats,
        repairMessages: repairMessages,
        validateEnvelope: validateEnvelope
    };
}());

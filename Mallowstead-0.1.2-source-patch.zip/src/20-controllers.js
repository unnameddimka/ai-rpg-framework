(function () {
    "use strict";

    let inFlight = false;
    setup.AITransientDebug = {
        lastContext: null,
        lastMessages: null,
        lastRawContent: "",
        lastParsedResponse: null,
        lastUsage: null,
        lastSafeError: "",
        lastRequest: null,
        lastTrace: null
    };

    function log(controllerId, actorId, message) {
        setup.Game.logController({
            controllerId: controllerId,
            actorId: actorId,
            message: message
        });
    }

    setup.Controllers = {
        human: {
            id: "human",

            takeTurn: function (actorId) {
                log("human", actorId, "Waiting for browser input.");
                return {
                    ok: true,
                    waitingForHumanInput: true,
                    actions: []
                };
            },

            onEvent: function (actorId, event) {
                log("human", actorId, `Observed event ${event.id}: ${event.type}.`);
                return { processed: true, actions: [] };
            }
        },

        dummy: {
            id: "dummy",

            takeTurn: function (actorId) {
                log("dummy", actorId, "DummyController took no action.");
                return { ok: true, actions: [] };
            },

            onEvent: function (actorId, event) {
                log("dummy", actorId, `Ignored event ${event.id}: ${event.type}.`);
                return { processed: true, actions: [] };
            }
        },

        ai: {
            id: "ai",
            implemented: true,

            takeTurn: function (actorId, client) {
                return takeQueuedTurn(actorId, client || setup.OpenRouterClient);
            },

            onEvent: function (actorId, event) {
                log("ai", actorId, `Queued event ${event.id} for an AI reaction turn.`);
                return { processed: false, actions: [] };
            }
        }
    };

    function clone(value) {
        return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
    }

    function combineNarrative(response) {
        const text = [];
        if (response.publicNarrative && response.publicNarrative.trim()) {
            const narrative = response.publicNarrative.trim().replace(/\*/g, "");
            if (narrative) text.push(`*${narrative}*`);
        }
        if (response.spokenText && response.spokenText.trim()) text.push(response.spokenText.trim());
        return text.join("\n");
    }

    function recordFailure(error) {
        const safe = error && error.code && error.message ? error.message : "Unexpected AI turn failure.";
        setup.AITransientDebug.lastSafeError = safe;
        const normalized = { code: error && error.code || "AI_TURN_FAILED", message: safe };
        if (error && Array.isArray(error.details)) normalized.details = clone(error.details);
        if (error && Number.isFinite(error.status)) normalized.status = error.status;
        if (error && Number.isFinite(error.retryAfterMs)) normalized.retryAfterMs = error.retryAfterMs;
        if (error && error.providerResponse) normalized.providerResponse = clone(error.providerResponse);
        return { ok: false, error: normalized };
    }

    function recordProtocolResult(actorId, stage, messages, result) {
        const trace = result && result.trace ? clone(result.trace) : null;
        const attempts = trace && Array.isArray(trace.attempts) ? trace.attempts : [];
        const lastAttempt = attempts.length > 0 ? attempts[attempts.length - 1] : null;
        setup.AITransientDebug.lastRequest = {
            actorId: actorId,
            stage: stage,
            messages: clone(messages)
        };
        setup.AITransientDebug.lastTrace = trace;
        setup.AITransientDebug.lastMessages = clone(messages);
        setup.AITransientDebug.lastRawContent = result && typeof result.rawContent === "string"
            ? result.rawContent
            : (lastAttempt && lastAttempt.rawContent || "");
        setup.AITransientDebug.lastParsedResponse = result && result.value
            ? clone(result.value)
            : (lastAttempt && lastAttempt.parsedValue ? clone(lastAttempt.parsedValue) : null);
        setup.AITransientDebug.lastUsage = result && result.usage
            ? clone(result.usage)
            : (lastAttempt && lastAttempt.usage ? clone(lastAttempt.usage) : null);
    }

    async function commitDecision(actorId, decision, consumedIds, client) {
        const narrativeText = combineNarrative(decision);
        let intentResult = { ok: true, action: decision.action, actionResult: null, narrativeResult: null, narrativeSuppressed: false };
        let actionFailed = false;

        if (decision.action) {
            const currentValidation = setup.CharacterAPI.validateActionRequest(actorId, decision.action);
            if (!currentValidation.ok) {
                const groundedFailure = setup.CharacterAPI.recordGroundedActionFailure(actorId, decision.action, {
                    code: "ACTION_NO_LONGER_AVAILABLE",
                    message: currentValidation.error.message
                });
                intentResult = {
                    ok: true,
                    action: clone(decision.action),
                    actionResult: clone(groundedFailure),
                    narrativeResult: null,
                    narrativeSuppressed: Boolean(narrativeText)
                };
                actionFailed = true;
            }
        }

        if (!actionFailed && (decision.action || narrativeText)) {
            intentResult = setup.CharacterAPI.submitIntent(actorId, {
                text: narrativeText,
                publicNarrative: decision.publicNarrative,
                spokenText: decision.spokenText,
                target_id: decision.spokenTargetId || "",
                noticeability: decision.spokenLoudness || undefined,
                action: decision.action
            });
            if (!intentResult.ok) throw intentResult.error;
            actionFailed = Boolean(decision.action && intentResult.actionResult && !intentResult.actionResult.ok);
        }

        if (!actionFailed && intentResult.actionResult && intentResult.actionResult.ok && setup.ItemModelEffects) {
            const modelEffects = await setup.ItemModelEffects.resolveActionResult(
                actorId,
                intentResult.actionResult,
                client || setup.OpenRouterClient
            );
            if (!modelEffects.ok) throw modelEffects.error;
        }

        if (!actionFailed) {
            const memoryResult = setup.AIMemory.applyUpdates(actorId, decision.memoryUpdates);
            if (!memoryResult.ok) throw memoryResult.error;
        }

        const continuationResult = setup.AIWorkingState.setContinuation(actorId, decision.continuation);
        if (!continuationResult.ok) throw continuationResult.error;

        const consumeResult = setup.AIMemory.consumeObservations(actorId, consumedIds);
        if (!consumeResult.ok) throw consumeResult.error;

        setup.AITurnQueue.remove(actorId);
        const actor = setup.Game.getWorld().entities[actorId];
        if (actor.mind.pendingObservations.length > 0) {
            setup.AITurnQueue.enqueue(actorId, "next_reaction_wave");
        }

        const validation = setup.Game.validateWorld();
        if (!validation.ok) throw validation.error;
        const narrativeCommitted = Boolean(intentResult.narrativeResult);
        return {
            narrativeText: narrativeCommitted ? narrativeText : "",
            narrativeSuppressed: Boolean(narrativeText && !narrativeCommitted),
            memorySuppressed: actionFailed,
            intentResult: clone(intentResult),
            actionResult: intentResult.actionResult ? clone(intentResult.actionResult) : null
        };
    }

    async function takeQueuedTurn(expectedActorId, client) {
        if (setup.Game.isPlayerSetupComplete && !setup.Game.isPlayerSetupComplete()) return recordFailure({ code: "PLAYER_SETUP_INCOMPLETE", message: "Complete Traveler setup before AI processing begins." });
        if (inFlight) return recordFailure({ code: "AI_TURN_IN_FLIGHT", message: "An AI turn is already in progress." });
        const status = setup.AITurnQueue.getStatus();
        if (!status.head) return recordFailure({ code: "AI_QUEUE_EMPTY", message: "No pending AI turns." });

        const actorId = expectedActorId || status.head.characterId;
        if (!status.entries.some(function (entry) { return entry.characterId === actorId; })) {
            return recordFailure({ code: "AI_QUEUE_ENTRY_MISSING", message: "The requested AI character is no longer queued." });
        }

        const before = JSON.stringify(setup.Game.getWorld());
        inFlight = true;
        setup.AITransientDebug.lastSafeError = "";
        try {
            const request = setup.AITurnScheduler.buildDecisionRequest(actorId, { skipContext: true });
            if (!request.ok) throw request.error;
            const retrieval = setup.MindSemanticRetrieval
                ? await setup.MindSemanticRetrieval.select(actorId, request.observations, client || setup.OpenRouterClient)
                : { ok: true, selection: setup.CharacterContext.selectMindDeterministically(actorId, request.observations), fallbackUsed: true };
            if (!retrieval.ok) throw retrieval.error;
            const context = setup.ContextBuilder.build(actorId, { pendingObservations: request.observations, mindSelection: retrieval.selection });
            if (context && context.ok === false) throw context.error;
            const messages = setup.AIProtocol.decisionMessages(context);
            const observationIds = clone(request.observationIds);
            setup.AITransientDebug.lastContext = clone(context);
            setup.AITransientDebug.lastMessages = clone(messages);

            const decisionResult = await setup.AIRequestExecutor.execute({
                actorId: actorId,
                purpose: "game-decision",
                messages: messages,
                stage: "decision",
                requestOptions: setup.AIRequestProfiles.resolve("game-decision", { actorId: actorId }),
                client: client
            });
            recordProtocolResult(actorId, "decision", messages, decisionResult);
            if (!decisionResult.ok) throw decisionResult.error;

            let finalDecision = clone(decisionResult.value);
            let contractRepair = null;
            if (setup.AIActionContractRepair && typeof setup.AIActionContractRepair.inspectAndRepair === "function") {
                contractRepair = await setup.AIActionContractRepair.inspectAndRepair(actorId, context, finalDecision, client || setup.OpenRouterClient);
                if (!contractRepair.ok) throw contractRepair.error;
                finalDecision = clone(contractRepair.value);
            }

            const committed = await commitDecision(actorId, finalDecision, observationIds, client);
            log("ai", actorId, contractRepair && contractRepair.repaired ? "Completed one AI reaction turn after Utility action-contract repair." : "Completed one single-request AI reaction turn.");
            return {
                ok: true,
                actorId: actorId,
                stages: 1,
                actionResult: committed.actionResult,
                intentResult: committed.intentResult,
                narrativeText: committed.narrativeText,
                narrativeSuppressed: committed.narrativeSuppressed,
                memorySuppressed: committed.memorySuppressed,
                usage: decisionResult.usage || null,
                contractRepair: contractRepair ? { triggered: contractRepair.triggered === true, repaired: contractRepair.repaired === true, noViolation: contractRepair.noViolation === true, detection: clone(contractRepair.detection || null), usage: contractRepair.repairResult && contractRepair.repairResult.usage || null } : null,
                retrieval: { semantic: retrieval.semantic === true, fallbackUsed: retrieval.fallbackUsed === true, selectorUsage: retrieval.selectorResult && retrieval.selectorResult.usage || null }
            };
        } catch (error) {
            State.variables.world = JSON.parse(before);
            return recordFailure(error);
        } finally {
            inFlight = false;
        }
    }

    setup.AIController = {
        takeNextTurn: function (client) {
            const schedulerHead = setup.AITurnScheduler && setup.AITurnScheduler.getQueueView
                ? setup.AITurnScheduler.getQueueView().head
                : null;
            const fallbackHead = schedulerHead || setup.AITurnQueue.peek();
            return takeQueuedTurn(fallbackHead && fallbackHead.characterId, client || setup.OpenRouterClient);
        },
        takeQueuedTurn: function (characterId, client) {
            return takeQueuedTurn(characterId, client || setup.OpenRouterClient);
        },
        isInFlight: function () {
            const status = setup.AIRequestExecutor && setup.AIRequestExecutor.getStatus ? setup.AIRequestExecutor.getStatus() : null;
            return inFlight || Boolean(status && (status.blockingBusy !== undefined ? status.blockingBusy : status.busy));
        },
        clearDebug: function () {
            setup.AITransientDebug.lastContext = null;
            setup.AITransientDebug.lastMessages = null;
            setup.AITransientDebug.lastRawContent = "";
            setup.AITransientDebug.lastParsedResponse = null;
            setup.AITransientDebug.lastUsage = null;
            setup.AITransientDebug.lastSafeError = "";
            setup.AITransientDebug.lastRequest = null;
            setup.AITransientDebug.lastTrace = null;
        }
    };
}());

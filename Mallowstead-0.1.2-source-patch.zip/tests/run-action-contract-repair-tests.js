"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");
const root = path.resolve(__dirname, "..");
global.setup = {};
global.State = { variables: {}, passage: "The Tavern" };
global.Engine = { play: function () {}, show: function () {} };
function load(file) { vm.runInThisContext(fs.readFileSync(path.join(root, file), "utf8"), { filename: file }); }
function assert(value, message) { if (!value) throw new Error(message); }
function clone(value) { return JSON.parse(JSON.stringify(value)); }
function emptyUpdates() { return { relationshipsToUpsert: [], activatedBeliefIds: [] }; }
function modelResponse(value) { return { ok: true, content: JSON.stringify(value), usage: null, modelId: "test-utility" }; }
function fresh() {
    setup.Game.resetWorld();
    setup.Game.acceptPlayerDisclaimer();
    setup.Game.acknowledgeAISetup();
    setup.Game.finalizePlayerSetup({ mode: "generic" });
    setup.AIActionContractRepair.resetStats();
    return setup.Game.getWorld();
}
function moveItem(world, itemId, targetInventoryId) {
    const item = world.entities[itemId];
    assert(item && item.type === "item", `item ${itemId} must exist`);
    Object.values(world.inventories).forEach(function (inventory) {
        if (!inventory || !Array.isArray(inventory.itemIds)) return;
        inventory.itemIds = inventory.itemIds.filter(function (id) { return id !== itemId; });
    });
    const target = world.inventories[targetInventoryId];
    assert(target, `target inventory ${targetInventoryId} must exist`);
    if (!target.itemIds.includes(itemId)) target.itemIds.push(itemId);
    item.inventoryId = targetInventoryId;
    delete item.equippedByCharacterId;
    delete item.equippedSlot;
}
function addItem(world, itemId, definitionId, inventoryId) {
    world.entities[itemId] = { id: itemId, type: "item", definitionId: definitionId, inventoryId: inventoryId };
    world.inventories[inventoryId].itemIds.push(itemId);
}
function hasRelevant(actorId, type) {
    const mechanics = setup.CharacterAPI.getRelevantMechanics(actorId);
    return Boolean(mechanics && mechanics[type]);
}
function hasAvailable(actorId, type) {
    const view = setup.CharacterAPI.getView(actorId);
    return Boolean(view && view.available_actions && view.available_actions[type]);
}

[
    "src/00-model-list.js", "src/generated/world-data.js", "src/07-mind-v3.js", "src/08-mind-validators.js",
    "src/09-passage-rules.js", "src/09-world-derived-state.js", "src/10-game-api.js", "src/10-weekly-rhythm.js",
    "src/11-save-migration.js", "src/12-character-context.js", "src/13-character-memory.js", "src/13-verbatim-memory.js",
    "src/14-event-perception.js", "src/16-emergency-diagnostics.js", "src/17-runtime-diagnostics.js",
    "src/21-ai-settings.js", "src/21-ai-request-profiles.js", "src/22-openrouter-client.js", "src/23-ai-protocol.js",
    "src/23-structured-ai-request.js", "src/23-z-action-contract-repair.js", "src/24-ai-request-executor.js"
].forEach(load);

async function main() {
    let world = fresh();

    // fill: source present is the relevance anchor; vessel is a strict prerequisite.
    assert(world.entities.innkeeper.sublocationId === "barBehindCounter", "Garrick fixture must start behind the bar");
    assert(hasRelevant("innkeeper", "fill"), "ale source present should make fill relevant without a mug");
    assert(!hasAvailable("innkeeper", "fill"), "fill must remain unavailable until Garrick has a compatible mug");
    moveItem(world, "emptyMug_1", "inventory_innkeeper");
    assert(hasRelevant("innkeeper", "fill") && hasAvailable("innkeeper", "fill"), "ale source + held mug should make fill relevant and available");
    world.entities.innkeeper.locationId = "commonRoom";
    world.entities.innkeeper.sublocationId = "commonRoomFloor";
    assert(!hasRelevant("innkeeper", "fill") && !hasAvailable("innkeeper", "fill"), "mug without ale source must not expose fill as relevant");

    // write: paper is the relevance anchor; writing set is a strict prerequisite.
    world = fresh();
    addItem(world, "repairTestPaper", "paperSheet", "inventory_player");
    assert(hasRelevant("player", "write_paper"), "paper present should make write_paper relevant without writing set");
    assert(!hasAvailable("player", "write_paper"), "write_paper must remain unavailable without writing set");
    addItem(world, "repairTestWritingSet", "writingSet", "inventory_player");
    assert(hasRelevant("player", "write_paper") && hasAvailable("player", "write_paper"), "paper + writing set should make write_paper relevant and available");
    moveItem(world, "repairTestPaper", "inventory_barMugCabinet");
    assert(!hasRelevant("player", "write_paper") && !hasAvailable("player", "write_paper"), "writing set without grounded paper must not expose write_paper");

    // unlock: locked passage is the relevance anchor; key is strict prerequisite.
    world = fresh();
    let moved = setup.CharacterAPI.perform("player", { type: "move", destination_id: "commonRoom" });
    assert(moved.ok, "player should enter common room for unlock relevance fixture");
    moved = setup.CharacterAPI.perform("player", { type: "move", destination_id: "upstairsCorridor" });
    assert(moved.ok, "player should reach upstairs corridor for unlock relevance fixture");
    assert(hasRelevant("player", "unlock"), "locked guest-room passage should make unlock relevant without a key");
    assert(!hasAvailable("player", "unlock"), "unlock must remain unavailable without matching key");
    moveItem(world, "guestRoom1Key", "inventory_player");
    assert(hasRelevant("player", "unlock") && hasAvailable("player", "unlock"), "locked passage + matching key should make unlock relevant and available");

    // Item-specific mechanics must not leak globally when the item is absent/ungrounded.
    world = fresh();
    const relevantAtStart = setup.CharacterAPI.getRelevantMechanics("player");
    assert(!relevantAtStart.use_item || !(relevantAtStart.use_item.itemSpecific || []).some(function (entry) { return entry.itemName === "Memory Stone"; }),
        "Memory Stone item-specific mechanic must not leak when the stone is not grounded for the player");

    // Decision prompt must teach relevant-vs-available semantics and remove the old narrative-execution loophole.
    world = fresh();
    const context = setup.ContextBuilder.build("innkeeper", { pendingObservations: [] });
    assert(context.relevantMechanics && context.relevantMechanics.fill, "Character context must contain relevant mechanics");
    const decisionMessages = setup.AIProtocol.decisionMessages(context);
    const systemPrompt = decisionMessages[0].content;
    assert(systemPrompt.includes("RELEVANT ENGINE MECHANICS") && systemPrompt.includes("AVAILABLE ACTIONS RIGHT NOW"),
        "decision prompt must distinguish relevant mechanics from executable-now actions");
    assert(systemPrompt.includes("Never narrate a completed tracked state change merely because its formal action is currently unavailable"),
        "decision prompt must forbid narrative completion of unavailable tracked mechanics");
    assert(!systemPrompt.includes("If the engine provides no grounded mechanic at all"), "old unsupported-physical-behavior narrative loophole must be removed");

    // Detector is a conservative trigger across narrative and speech, including unmatched mechanics when another action is selected.
    world = fresh();
    let detection = setup.AIActionContractRepair.detect({
        action: null,
        publicNarrative: "Garrick fills the mug from the tap.",
        spokenText: null
    });
    assert(detection.triggered && detection.signals.some(function (signal) { return signal.mechanicType === "fill" && signal.field === "publicNarrative"; }),
        "detector must trigger on narrative fill claim without formal action");
    detection = setup.AIActionContractRepair.detect({
        action: { type: "move", destination_id: "commonRoom" },
        publicNarrative: "Garrick walks to the door and locks it.",
        spokenText: null
    });
    assert(detection.triggered && detection.signals.some(function (signal) { return signal.mechanicType === "lock"; }),
        "detector must trigger on a tracked mechanic not covered by selected move action");
    detection = setup.AIActionContractRepair.detect({
        action: null,
        publicNarrative: null,
        spokenText: "Here, take the coin. I paid already."
    });
    assert(detection.triggered && detection.signals.some(function (signal) { return signal.field === "spokenText" && signal.mechanicType === "give_money"; }),
        "detector must scan spokenText as well as publicNarrative");

    // Detector false positives are resolved by Utility, not deterministically rejected.
    world = fresh();
    let repairContext = setup.ContextBuilder.build("innkeeper", { pendingObservations: [] });
    setup.AIActionContractRepair.resetStats();
    const futureIntentDecision = {
        action: null,
        publicNarrative: null,
        spokenText: "I'll fill the mugs next.",
        spokenTargetId: null,
        spokenLoudness: "noticeable",
        continuation: null,
        memoryUpdates: emptyUpdates()
    };
    const noViolation = await setup.AIActionContractRepair.inspectAndRepair("innkeeper", repairContext, futureIntentDecision, {
        chat: async function () { return modelResponse({ violation: false, repairedDecision: null }); }
    });
    assert(noViolation.ok && noViolation.noViolation === true && noViolation.repaired === false,
        "Utility must be able to clear an innocent detector trigger without changing the Character response");
    let stats = setup.AIActionContractRepair.getStats();
    assert(stats.characterDecisions === 1 && stats.detectorTriggered === 1 && stats.repairAttempted === 1 && stats.repairNoViolation === 1,
        "repairNoViolation statistics must record conservative detector false positives");

    // Garrick retail regression: taking/filling/serving in narrative must repair to the available prerequisite transfer_items.
    world = fresh();
    repairContext = setup.ContextBuilder.build("innkeeper", { pendingObservations: [] });
    const transfer = repairContext.view.available_actions.transfer_items;
    assert(repairContext.relevantMechanics.fill && !repairContext.view.available_actions.fill && transfer,
        "Garrick regression fixture requires relevant-but-unavailable fill plus available transfer_items");
    const route = transfer.options.routes.find(function (candidate) {
        return candidate.source_inventory_id === "inventory_barMugCabinet" && candidate.target_inventory_id === "inventory_innkeeper";
    });
    assert(route && route.item_ids.includes("emptyMug_1") && route.item_ids.includes("emptyMug_2"), "Garrick fixture must expose two cabinet mugs on transfer route");
    const badDecision = {
        action: null,
        publicNarrative: "Garrick takes two clean mugs, fills them from the tap, and slides them toward Nell.",
        spokenText: null,
        spokenTargetId: null,
        spokenLoudness: null,
        continuation: null,
        memoryUpdates: emptyUpdates()
    };
    const repairedDecision = {
        action: {
            type: "transfer_items",
            source_inventory_id: "inventory_barMugCabinet",
            target_inventory_id: "inventory_innkeeper",
            item_ids: ["emptyMug_1", "emptyMug_2"]
        },
        publicNarrative: "Garrick takes two clean mugs from the cabinet.",
        spokenText: null,
        spokenTargetId: null,
        spokenLoudness: null,
        continuation: "Serve two ales to Nell.",
        memoryUpdates: emptyUpdates()
    };
    setup.AIActionContractRepair.resetStats();
    const repaired = await setup.AIActionContractRepair.inspectAndRepair("innkeeper", repairContext, badDecision, {
        chat: async function () { return modelResponse({ violation: true, repairedDecision: repairedDecision }); }
    });
    assert(repaired.ok && repaired.repaired === true && repaired.value.action && repaired.value.action.type === "transfer_items",
        "Utility must repair Garrick's narrative shortcut into the available prerequisite transfer_items action");
    assert(repaired.value.continuation === "Serve two ales to Nell." && !/fill/i.test(repaired.value.publicNarrative),
        "repaired decision must preserve unfinished intent without narrating later fill completion");
    stats = setup.AIActionContractRepair.getStats();
    assert(stats.repairSucceeded === 1 && stats.repairedActions.transfer_items === 1 && stats.triggerMechanics.fill === 1,
        "successful Garrick repair must be visible in aggregate repair statistics");

    // If Utility confirms a violation but cannot provide a valid current action, reject the whole response.
    world = fresh();
    repairContext = setup.ContextBuilder.build("innkeeper", { pendingObservations: [] });
    const worldBeforeReject = JSON.stringify(world);
    setup.AIActionContractRepair.resetStats();
    const rejected = await setup.AIActionContractRepair.inspectAndRepair("innkeeper", repairContext, badDecision, {
        chat: async function () { return modelResponse({ violation: true, repairedDecision: null }); }
    });
    assert(!rejected.ok && rejected.error.code === "ACTION_CONTRACT_REPAIR_NO_ACTION", "confirmed violation with no valid repair action must reject the whole response");
    assert(JSON.stringify(setup.Game.getWorld()) === worldBeforeReject, "failed repair must not mutate canonical world state");
    stats = setup.AIActionContractRepair.getStats();
    assert(stats.repairWholeResponseRejected === 1, "whole-response rejection must be counted");

    // An invalid invented repair must also reject rather than falling back to partial narrative/speech.
    setup.AIActionContractRepair.resetStats();
    const invalidRepair = clone(repairedDecision);
    invalidRepair.action = { type: "fill", item_id: "emptyMug_1" }; // fill is not currently available in this context.
    const rejectedInvalid = await setup.AIActionContractRepair.inspectAndRepair("innkeeper", repairContext, badDecision, {
        chat: async function () { return modelResponse({ violation: true, repairedDecision: invalidRepair }); }
    });
    assert(!rejectedInvalid.ok && rejectedInvalid.error.code === "ACTION_CONTRACT_REPAIR_FAILED",
        "Utility repair that invents an unavailable action must fail structured validation and reject the Character response");
    assert(setup.AIActionContractRepair.getStats().repairWholeResponseRejected === 1, "invalid repaired action must increment whole-response rejection count");

    // Emergency dump exposes bounded aggregate statistics.
    const dump = setup.EmergencyDiagnostics.captureFiles();
    assert(dump.files["action-contract-repair.json"] && typeof dump.files["action-contract-repair.json"].characterDecisions === "number",
        "emergency dump must include action-contract repair statistics");

    console.log("Action-contract relevance/repair tests passed.");
}

main().catch(function (error) {
    console.error(error && error.stack || error);
    process.exit(1);
});

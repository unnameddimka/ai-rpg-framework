# Mallowstead AI Action Contract Hardening
## Relevant Mechanics, Deterministic Repair Trigger, and Utility Repair Pass

**Status:** Implementation specification  
**Scope:** Character decision protocol hardening for cheaper/less reliable character models, especially Flash  
**Primary goal:** Make the Character model produce a correct formal action on the first pass whenever possible, while adding a narrow repair safety net for narrative claims that bypass formal engine mechanics.

---

# 1. Problem Statement

Mallowstead already treats the engine as the authority for tracked world state and exposes only currently executable actions through `available_actions`.

However, the Character model currently has insufficient information to distinguish:

- a mechanic that does not exist at all;
- a mechanic that exists but is not currently available because one or more prerequisites are missing.

This causes failures such as:

- an ale tap is present;
- empty mugs are still in a cabinet;
- `fill` is not currently in `available_actions`;
- `transfer_items` is available and would obtain the required mugs;
- the Character model incorrectly concludes that filling/pouring is unsupported;
- the model narrates taking, filling, and serving mugs without any formal action.

The existing prompt also contains or has contained language permitting unsupported physical behavior to be described narratively when no grounded mechanic exists. In the current protocol this is unsafe because the model cannot reliably determine whether a mechanic truly does not exist or is merely unavailable in the current state.

The solution is not to make Utility repair mandatory on every turn.

The target architecture is:

```text
Character model
    ↓
usually correct first-pass decision
    ↓
deterministic suspicious-effect detector
    ↓ only when suspicious
Utility action-contract repair
    ↓
normal deterministic validation
    ↓
commit OR reject whole Character response
```

The first-pass Character model remains the primary decision-maker.

---

# 2. Core Invariants

## 2.1 Formal actions are the only execution channel for tracked effects

Narrative and speech are never an alternate execution channel for canonical state transitions.

If an effect would change tracked world state, it must be represented by a valid formal action.

Examples include, but are not limited to:

- item possession;
- item/container location;
- item state;
- filling/emptying;
- consuming;
- giving;
- money transfer;
- equipment state;
- character location;
- tracked posture/position;
- opening/closing/locking/unlocking passages;
- authored item-specific state changes;
- any other engine-owned canonical state.

The Character model may describe cosmetic/untracked gestures and behavior, but must not claim a tracked effect as completed unless the returned formal action covers that effect.

---

## 2.2 `relevant mechanics` and `available_actions` are different concepts

The Character decision request must clearly communicate two separate sets:

### Relevant mechanics

Mechanics that are grounded in the current scene/item context and may become executable after satisfying prerequisites.

These descriptions teach the Character model what the engine supports **here**, without exposing the whole world or whole ActionRegistry.

### Available actions

The existing authoritative set of actions that can be executed **right now**, including concrete targets/options.

A mechanic may be relevant but unavailable.

Example:

```text
Relevant mechanics:
- fill: Fill a compatible vessel from the ale tap.
  Prerequisites: actor must have/access a compatible vessel and be at the tap.

Available actions:
- transfer_items: take empty mugs from Mug cabinet
```

The intended reasoning is:

```text
I want to fill mugs.
fill exists here but is not currently available.
Its prerequisite requires a compatible vessel.
transfer_items can obtain the vessel.
Therefore perform transfer_items now.
```

---

# 3. Action Definition Metadata

Each formal action definition, including both generic actions and item-specific actions, must support AI-facing metadata.

Exact property names may follow project conventions, but the semantics below are required.

Conceptually:

```text
aiDescription
aiPrerequisites
repairKeywords
relevantActionSources(...)
grantedActionSources(...) / existing strict availability logic
```

The implementation should extend the existing ActionRegistry/action-source architecture rather than introducing a separate unrelated anchor framework.

---

## 3.1 `aiDescription`

A short, stable AI-facing description of what the mechanic does.

Example:

```text
transfer_items:
Move one or more accessible items between inventories or containers.

fill:
Fill a compatible vessel from a compatible source.

write_paper:
Write or draw on a writable paper sheet.

unlock:
Unlock a locked passage using a compatible key.
```

Descriptions must be:

- concise;
- mechanical;
- free of hidden world information;
- independent of current concrete target IDs/options;
- useful for prerequisite reasoning.

---

## 3.2 `aiPrerequisites`

A concise AI-facing description of conditions required for the action to become available.

Examples:

```text
fill:
- a compatible fill source must be present/usable in the actor's current position;
- a compatible vessel must be accessible/held by the actor.

write_paper:
- a writable paper sheet must be accessible;
- an appropriate writing capability/tool must be available.

unlock:
- a locked passage must be present;
- the actor must possess/access a compatible key.

equip:
- the item must be accessible;
- the relevant equipment slot(s) must be available.
```

The Character model does not receive hidden state values through these descriptions.

The descriptions explain general prerequisites only.

---

## 3.3 `repairKeywords`

Each tracked formal mechanic may define a conservative set of words, stems, or short phrases associated with narrating that mechanic.

Examples:

```text
fill:
- fill
- fills
- filled
- filling
- pour
- pours
- poured
- pouring
- tap

transfer_items:
- take
- takes
- took
- grab
- grabs
- retrieve
- remove from
- put into
- place into

give_item:
- give
- gives
- gave
- hand
- hands
- handed
- pass
- passes
- passed
- slide toward
- slides toward

unlock:
- unlock
- unlocks
- unlocked
- turn the key

lock:
- lock
- locks
- locked
- bolt
- bolts
- barred
```

These keywords are **not a validator** and do not themselves prove a violation.

They are only a cheap deterministic signal used to decide whether a Utility repair pass may be necessary.

False positives are acceptable.

False negatives should be reduced over time using real retail playtest failures.

---

# 4. Relevant-Mechanics Source Gating

## 4.1 Reuse the existing source/availability architecture

The project already derives action availability through action sources and strict prerequisites.

Extend that system so an action can answer two questions:

```text
Is this mechanic relevant enough to explain to this actor now?
Is this action executable right now?
```

The existing strict path remains authoritative for `available_actions`.

Add a relaxed relevance path for AI-facing mechanics.

Do not create a global always-visible catalog of every action in the game.

---

## 4.2 Relaxed source rule

For relevant mechanics, evaluate the action as though **non-anchor prerequisites may be missing**.

The mechanic is shown when its primary grounded source/anchor is present or accessible in the current actor context.

Examples below are normative.

### Writing on paper

```text
paper present, writing kit absent:
    relevant = yes
    available = no

paper present, writing kit present:
    relevant = yes
    available = yes

paper absent, writing kit present:
    relevant = no
    available = no
```

The paper is the relevance anchor.

---

### Filling from an ale source

```text
ale source present, mug absent:
    relevant = yes
    available = no

ale source present, mug present:
    relevant = yes
    available = yes

ale source absent, mug present:
    relevant = no
    available = no
```

The fill source is the relevance anchor.

This is required to solve the Garrick serving-ale failure mode.

---

### Unlocking a passage

```text
locked passage present, matching key absent:
    relevant = yes
    available = no

locked passage present, matching key present:
    relevant = yes
    available = yes

no relevant locked passage:
    relevant = no
```

The passage is the relevance anchor.

---

### Equipping an item

```text
equippable item accessible, required slot occupied:
    relevant = yes
    available = no

equippable item accessible, slot available:
    relevant = yes
    available = yes

no relevant equippable item accessible:
    relevant = no
```

The item is the relevance anchor.

---

## 4.3 Item-specific mechanics

Item-specific actions are relevant only when their defining/anchoring item is grounded for the actor under normal visibility/access rules.

Examples:

- paper-specific read/write mechanics require relevant paper;
- Memory Stone-specific use requires the stone to be grounded;
- future special artifact actions require the relevant artifact to be grounded.

Do not expose item-specific mechanics merely because their action definitions exist somewhere in the world.

---

## 4.4 General/source-less mechanics

Do not automatically send every source-less action in the registry.

For an action with no meaningful relaxed source concept:

- include it when its current relevance rule says it belongs to the current actor/context;
- if no separate relevance rule is appropriate, it is sufficient to include it only when currently available.

The implementation must avoid turning `relevant mechanics` into a global encyclopedia of Mallowstead actions.

---

# 5. Character Decision Request

Add a compact AI-facing section to the Character decision prompt.

Conceptually:

```text
RELEVANT ENGINE MECHANICS

These are mechanics grounded in your current scene or accessible items.
A mechanic listed here may still be unavailable right now because one or more
prerequisites are missing.

<mechanic descriptions + prerequisites>

AVAILABLE ACTIONS RIGHT NOW

Only these concrete formal actions may be executed in this response.

<existing available_actions>
```

Include an explicit rule near this section:

> Relevant mechanics describe what the engine can support in the current grounded context. `available_actions` describes what may be executed right now. If your intended mechanic is relevant but unavailable, look for an available prerequisite action that advances the same intention.

Also include:

> Never narrate a completed tracked state change merely because its formal action is currently unavailable. The required action may become available after a prerequisite.

---

# 6. Prompt Contract Change

Remove/replace any existing instruction equivalent to:

> If the engine provides no grounded mechanic at all for an action class, unsupported physical behavior may be completed narratively.

This formulation is no longer permitted.

Replace it with the stronger invariant:

> Narrative may freely describe cosmetic or untracked behavior. Narrative must never claim completion of an engine-tracked state change unless the returned formal action covers that state change.

If no appropriate formal action is available:

- use an available prerequisite action if one clearly advances the intention;
- otherwise do not claim the tracked result as completed;
- preserve unfinished purpose through the normal continuation mechanism when appropriate.

---

# 7. Deterministic Suspicious-Effect Detector

## 7.1 Purpose

The detector decides only:

> Is this response suspicious enough to justify a Utility repair pass?

It does not decide guilt.

It must not itself rewrite the Character response.

---

## 7.2 Inputs

At minimum:

- Character `publicNarrative`;
- Character `spokenText`;
- selected formal `action` if any;
- relevant mechanics for this Character request;
- complete `repairKeywords` metadata available to deterministic engine code;
- current `available_actions`.

The detector may know the complete engine registry because it is not an AI-facing information surface.

---

## 7.3 Scan both narrative and speech

Both `publicNarrative` and `spokenText` must be scanned.

Example:

```text
spokenText:
"Here, take the key," Garrick says, handing it over.

action:
null
```

This is potentially a tracked `give_item` claim and must be eligible for repair detection.

---

## 7.4 Trigger behavior

Keyword matches are only signals.

Examples that may trigger:

```text
action = null
narrative mentions fill/pour/give/take/lock
```

and:

```text
action = move
narrative says actor moved to door and locked it
```

The latter must still trigger because the selected action does not cover the possible `lock` effect.

Conceptually compare:

```text
mechanic classes suggested by text
vs.
mechanic class covered by selected formal action
```

Any suspicious unmatched tracked-mechanic class may trigger repair.

---

## 7.5 Do not deterministically reject based on keywords alone

Examples such as:

```text
"I'll fill the mugs in a moment."
"Could you give Nell the key?"
"He looks at the locked door."
```

may contain action keywords without asserting completion.

Therefore the detector must not reject the response directly.

It invokes Utility repair/verification instead.

---

# 8. Utility Action-Contract Repair Pass

## 8.1 Invocation

Run Utility repair only when the deterministic detector triggers.

Do not make this a mandatory second model call for clean Character responses.

The objective is to maximize first-pass Character correctness and keep Utility repair as a rare safety mechanism.

---

## 8.2 Inputs

Provide only information necessary for repair:

- original Character decision;
- relevant mechanics for that Character request;
- concrete current `available_actions`;
- detector signals/matched mechanic classes;
- minimal relevant structured current state needed to understand targets/options;
- formal schema/contract necessary to return a valid repaired decision.

Do not expose unrelated hidden world state.

---

## 8.3 Repair task

Utility must not roleplay the character again or reconsider the entire scene from scratch.

Its task is:

> Preserve the Character model's expressed intention and voice as much as possible. Determine whether the response claims a tracked state change not represented by its formal action. If so, select at most one currently available formal action that legitimately advances the already-expressed intention, and rewrite the response so it does not claim completion beyond that action.

Important constraints:

- at most one formal action;
- action must exist in current `available_actions`;
- Utility must not invent unavailable actions;
- Utility may choose a prerequisite action;
- Utility should preserve valid speech/narrative/model-writable content where compatible with the repaired action;
- Utility must remove claims that jump ahead of the repaired atomic action;
- Utility is repairing contract compliance, not optimizing strategy.

---

## 8.4 Example: Garrick and the mugs

Initial state:

```text
- ale tap is present;
- two empty mugs are in Mug cabinet;
- Garrick does not currently hold the mugs;
- transfer_items from cabinet is available;
- fill is relevant but unavailable.
```

Bad Character output:

```text
action: null

publicNarrative:
Garrick takes two clean mugs, fills them from the tap, and slides them to Nell.
```

Detector:

```text
suspected mechanics:
- transfer_items
- fill
- give_item / transfer
```

Utility should repair toward the earliest valid atomic prerequisite, for example:

```text
action:
  transfer_items
  Mug cabinet -> Garrick
  [mug1, mug2]

publicNarrative:
Garrick reaches into the mug cabinet and takes out two clean mugs.

continuation:
Serve two ales to Nell.
```

Utility must not invent `fill` if `fill` is not currently available.

---

# 9. Repair Validation and Whole-Response Rejection

## 9.1 Successful repair

A repaired decision must pass the normal deterministic validation pipeline from scratch.

Do not trust Utility merely because it is a Utility model.

Validate:

- action schema;
- exact current availability/options;
- target IDs;
- quantities;
- protocol limits;
- model-writable updates;
- no-op rules;
- all other current decision-contract validators.

Only after successful validation may the repaired response be committed.

---

## 9.2 Failed repair

If any of the following occurs:

- Utility says a violation exists but cannot identify a valid available action needed to repair it;
- Utility invents an unavailable action;
- repaired action fails normal validation;
- repaired narrative still violates the contract;
- Utility output is malformed;
- Utility repair itself fails/throws/times out beyond existing request handling policy;

then:

> Reject and discard the entire original Character response.

Do not commit partial content.

Specifically discard:

- original formal action;
- public narrative;
- spoken text;
- continuation;
- model-writable mind/state updates from that Character response;
- any other response-side operations.

Do not trim only the narrative and continue.

Do not preserve only the speech.

Do not execute the original action.

The failed response should remain visible in diagnostics/AI interaction logging, but not canonical world state.

The character may react again later through the normal scheduler/observation lifecycle.

---

## 9.3 No-violation Utility result

The detector is intentionally conservative and may trigger on innocent wording.

Utility must be able to return:

```text
no violation
```

In that case, the original Character decision proceeds through the existing normal validation path unchanged.

Record the false-positive/`repairNoViolation` statistic.

---

# 10. Pending Observations / Retry Semantics

A response rejected due to failed action-contract repair must not be treated as a successfully committed reaction.

Preserve existing scheduler safety rules and avoid infinite immediate retry loops.

The failure should:

- be logged;
- leave the world unchanged;
- allow the character to react again on a later normal opportunity.

Do not implement an uncontrolled same-tick retry loop for Character generation as part of this specification.

The exact observation bookkeeping should follow existing scheduler semantics while preserving the invariant that rejected output did not successfully resolve the world-facing reaction.

---

# 11. Repair Statistics

Collect lightweight cumulative/session diagnostics for emergency dumps.

Required counters:

```text
characterDecisions
detectorTriggered
repairAttempted
repairNoViolation
repairSucceeded
repairWholeResponseRejected
```

Also collect compact per-mechanic trigger counts where practical:

```text
triggerMechanics:
  fill: N
  transfer_items: N
  give_item: N
  lock: N
  ...
```

Optionally collect successful repaired action-type counts:

```text
repairedActions:
  transfer_items: N
  fill: N
  ...
```

Do not create an unbounded per-request statistics history merely for these metrics.

Detailed individual calls already belong in the existing AI interaction/diagnostic logs.

---

## 11.1 Emergency dump

Include the repair statistics in the emergency dump in a clearly named diagnostics section.

The dump should make it easy to determine:

- how many Character decisions were first-pass clean;
- how often the detector triggered;
- how many triggers were false positives;
- how often Utility actually repaired a decision;
- how often the entire response had to be rejected;
- which mechanics most commonly caused suspicion.

This is specifically intended to evaluate Flash first-pass contract quality during retail playtesting.

---

# 12. Benchmark / Measurement Semantics

Repair must not hide Character-model quality.

Where model quality/contract-pass rates are measured, distinguish:

```text
first-pass Character contract success
detector trigger rate
Utility-confirmed violation rate
repair success rate
whole-response rejection rate
post-repair committed success
```

Do not report only the final post-repair success rate.

The project objective is still:

> The Character model should produce a correct formal decision on the first pass.

Repair is a safety net.

---

# 13. Implementation Notes for Existing Architecture

## 13.1 Prefer ActionRegistry as source of truth

Do not create a separate hand-maintained mechanics encyclopedia.

AI descriptions, prerequisites, keywords, and relevance logic should live with or be generated from the formal action definitions/registry architecture.

This avoids drift between:

- actual engine mechanics;
- Character-facing mechanic descriptions;
- repair detection.

---

## 13.2 Item action definitions

Item-specific formal actions must support the same metadata contract.

Examples:

```text
Read paper
Write / draw on paper
Squeeze Memory Stone
future item-defined actions
```

The item/action registry remains responsible for determining which item-specific mechanics are relevant for the actor.

---

## 13.3 Hidden mechanics

Relevant-mechanics generation must obey current grounding/visibility/access rules.

Do not reveal:

- actions anchored to hidden items;
- secret-location-specific actions when the actor lacks grounded access;
- future quest/arc mechanics;
- mechanics anchored to entities absent from the actor's relevant scene.

The deterministic detector may know their keywords internally, but AI-facing prompts must not gain hidden world knowledge from them.

---

# 14. Required Tests

## 14.1 Relevant mechanics

Add deterministic tests for at least:

### Paper writing

- paper present + no writing kit → `write` relevant, not available;
- paper present + writing kit → relevant and available;
- no paper + writing kit → not relevant.

### Fill

- ale source present + no mug → `fill` relevant, not available;
- ale source present + valid mug → relevant and available;
- no ale source + mug → `fill` not relevant.

### Unlock

- locked passage + no key → `unlock` relevant, not available;
- locked passage + key → relevant and available;
- no locked passage → not relevant.

### Item-specific action

- relevant item grounded → item-specific mechanic may be relevant;
- item not grounded → item-specific mechanic not exposed.

---

## 14.2 Character prompt

Test that the decision request contains:

- relevant mechanics;
- prerequisites;
- separate current `available_actions`;
- the explicit distinction between relevant vs executable-now mechanics;
- the prohibition on narratively completing tracked state changes.

Test that unrelated hidden/item-specific mechanics are absent.

---

## 14.3 Detector

Test:

```text
action=null
"Garrick fills the mug."
```

→ detector triggers `fill`.

Test:

```text
action=move
"Garrick walks to the door and locks it."
```

→ detector triggers unmatched `lock`.

Test both `publicNarrative` and `spokenText`.

Test that innocent keyword use still triggers if appropriate but is not deterministically rejected.

---

## 14.4 Utility no-violation

Example:

```text
"I'll fill the mugs next."
action = transfer_items
```

Detector may trigger `fill`.

Utility returns no violation.

Original response proceeds normally.

Counter:

```text
repairNoViolation += 1
```

---

## 14.5 Garrick ale regression fixture

Create a regression fixture based on the retail failure:

State:

- Garrick at ale tap/bar;
- empty mugs in Mug cabinet;
- no mugs currently held;
- request/intention to serve ale.

Bad Character response:

```text
action = null
publicNarrative claims taking mugs, filling them, and serving them.
```

Required:

- detector triggers;
- Utility sees `fill` as relevant but unavailable;
- Utility may select currently available `transfer_items`;
- repaired narrative describes only the atomic step covered by the selected action;
- repaired response passes normal validation.

---

## 14.6 Whole-response rejection

Test each of:

- Utility invents unavailable `fill`;
- Utility returns malformed action;
- Utility chooses invalid target;
- Utility claims violation but returns no usable action;
- repaired output fails normal validator.

Required result:

- no original Character action executes;
- no original speech commits;
- no original public narrative commits;
- no continuation commits;
- no model-writable updates commit;
- world remains unchanged;
- diagnostic entry records repair failure;
- `repairWholeResponseRejected` increments.

---

## 14.7 Statistics

Test counter increments for:

- clean first-pass response;
- detector trigger;
- Utility no-violation;
- successful repair;
- whole-response rejection;
- per-mechanic trigger counts.

Emergency dump must include the aggregated statistics.

---

# 15. Acceptance Criteria

This work is complete when:

1. Character decision requests explain relevant grounded mechanics even when non-anchor prerequisites are currently missing.
2. The model does not receive a global catalog of every action in the world.
3. Existing strict `available_actions` remain the only executable-now authority.
4. `fill` is explained to Garrick when the ale source is present even if he does not yet hold a mug.
5. `write` is explained when paper is present even if a writing prerequisite is missing.
6. Tracked state changes are no longer permitted to be completed narratively simply because their action is currently unavailable.
7. A deterministic keyword detector cheaply identifies suspicious narrative/speech and invokes Utility only when needed.
8. Keywords alone never deterministically reject a response.
9. Utility repair preserves the Character's intention and may select at most one currently available formal prerequisite/action.
10. Repaired output is fully revalidated through the normal deterministic contract.
11. If repair cannot produce a valid required action, the entire Character response is discarded.
12. No partial narrative/speech/model-writable output from a rejected Character response reaches canonical state.
13. Emergency dumps contain repair statistics sufficient to evaluate Flash first-pass quality.
14. Existing regression suites remain green, with the Garrick mug-serving failure added as an explicit regression case.
